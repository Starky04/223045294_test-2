# ShopEZ React Native App

Configured for Firebase project `shopez-3c15f`.

## Run
1. npm install
2. npm start
3. Use Login/Register to enter the app.
