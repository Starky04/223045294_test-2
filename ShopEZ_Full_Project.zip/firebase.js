import { initializeApp } from 'firebase/app';
import { getAuth, onAuthStateChanged, setPersistence, browserLocalPersistence } from 'firebase/auth';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyCSevJrCrCQsayhjFOJSSwMBqvsWJJ4Anw",
  authDomain: "shopez-3c15f.firebaseapp.com",
  databaseURL: "https://shopez-3c15f-default-rtdb.firebaseio.com",
  projectId: "shopez-3c15f",
  storageBucket: "shopez-3c15f.firebasestorage.app",
  messagingSenderId: "578654849485",
  appId: "1:578654849485:web:40bf8ecca0ad1e2fe7dc84",
  measurementId: "G-N6KQ59ZKCM"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getDatabase(app);
setPersistence(auth, browserLocalPersistence).catch(() => {});
export const watchAuth = (cb) => onAuthStateChanged(auth, cb);
