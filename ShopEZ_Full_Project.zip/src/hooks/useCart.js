import { useEffect, useMemo, useState } from 'react';
import { ref, onValue, set, remove } from 'firebase/database';
import { auth, db } from '../../firebase';
import { loadCartLocal, saveCartLocal } from '../utils/storage';

export default function useCart() {
  const [cart, setCart] = useState({});
  const uid = auth.currentUser?.uid;

  useEffect(() => {
    if (!uid) return;
    const r = ref(db, `carts/${uid}`);
    const off = onValue(r, async (snap) => {
      const val = snap.val() || {};
      setCart(val);
      saveCartLocal(val);
    }, async () => {
      const local = await loadCartLocal();
      setCart(local);
    });
    return () => off();
  }, [uid]);

  const items = useMemo(() => Object.values(cart || {}), [cart]);
  const total = useMemo(() => items.reduce((s, it) => s + (it.price * it.qty), 0), [items]);

  const add = async (product, qty = 1) => {
    if (!uid) return;
    const existing = cart[product.id] || { ...product, qty: 0 };
    const next = { ...existing, qty: existing.qty + qty };
    set(ref(db, `carts/${uid}/${product.id}`), next);
  };

  const updateQty = (productId, qty) => {
    if (!uid) return;
    if (qty <= 0) return remove(ref(db, `carts/${uid}/${productId}`));
    const curr = cart[productId];
    if (!curr) return;
    set(ref(db, `carts/${uid}/${productId}`), { ...curr, qty });
  };

  const removeItem = (productId) => remove(ref(db, `carts/${uid}/${productId}`));

  return { cart, items, total, add, updateQty, removeItem };
}
