import AsyncStorage from '@react-native-async-storage/async-storage';

const CART_KEY = 'shopez.cart';

export async function saveCartLocal(cart) {
  try { await AsyncStorage.setItem(CART_KEY, JSON.stringify(cart)); } catch {}
}

export async function loadCartLocal() {
  try {
    const raw = await AsyncStorage.getItem(CART_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}
