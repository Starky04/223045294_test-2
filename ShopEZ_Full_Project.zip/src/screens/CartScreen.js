import React from 'react';
import { View, Text, FlatList, Image, Pressable } from 'react-native';
import useCart from '../hooks/useCart';

export default function CartScreen() {
  const { items, total, updateQty, removeItem } = useCart();

  return (
    <View style={{ flex:1 }}>
      <FlatList
        data={items}
        keyExtractor={(it)=>String(it.id)}
        ListEmptyComponent={<Text style={{ textAlign:'center', marginTop:32 }}>Your cart is empty.</Text>}
        renderItem={({item}) => (
          <View style={{ flexDirection:'row', gap:12, padding:12, backgroundColor:'#fff', margin:12, borderRadius:12, elevation:2 }}>
            <Image source={{ uri: item.image }} style={{ width:70, height:70, resizeMode:'contain' }} />
            <View style={{ flex:1 }}>
              <Text numberOfLines={2} style={{ fontWeight:'600' }}>{item.title}</Text>
              <Text>R {item.price.toFixed(2)} x {item.qty} = <Text style={{fontWeight:'700'}}>R {(item.price*item.qty).toFixed(2)}</Text></Text>
              <View style={{ flexDirection:'row', gap:8, marginTop:8 }}>
                <Pressable onPress={()=>updateQty(item.id, item.qty-1)} style={btnSm}><Text style={btnSmText}>-</Text></Pressable>
                <Pressable onPress={()=>updateQty(item.id, item.qty+1)} style={btnSm}><Text style={btnSmText}>+</Text></Pressable>
                <Pressable onPress={()=>removeItem(item.id)} style={[btnSm,{backgroundColor:'#ef4444'}]}><Text style={btnSmText}>Remove</Text></Pressable>
              </View>
            </View>
          </View>
        )}
        ListFooterComponent={items.length ? (
          <View style={{ padding:16 }}>
            <Text style={{ fontSize:18, fontWeight:'800' }}>Total: R {total.toFixed(2)}</Text>
          </View>
        ) : null}
      />
    </View>
  );
}

const btnSm = { backgroundColor:'#111827', paddingHorizontal:12, paddingVertical:8, borderRadius:8 };
const btnSmText = { color:'#fff', fontWeight:'700' };
