import React from 'react';
import { View, Text, Image, Pressable, ScrollView } from 'react-native';
import useCart from '../hooks/useCart';

export default function ProductDetailScreen({ route }) {
  const { product } = route.params;
  const { add } = useCart();

  return (
    <ScrollView contentContainerStyle={{ padding:16, gap:12 }}>
      <Image source={{ uri: product.image }} style={{ width:'100%', height:300, resizeMode:'contain' }} />
      <Text style={{ fontSize:20, fontWeight:'700' }}>{product.title}</Text>
      <Text style={{ fontSize:16, color:'#374151' }}>{product.description}</Text>
      <Text style={{ fontSize:18, fontWeight:'800' }}>R {product.price.toFixed(2)}</Text>
      <Pressable onPress={()=>add(product,1)} style={({pressed})=>({ backgroundColor:'#111827', padding:14, borderRadius:12, alignItems:'center', opacity: pressed?0.8:1 })}>
        <Text style={{ color:'#fff', fontWeight:'700' }}>Add to Cart</Text>
      </Pressable>
    </ScrollView>
  );
}
