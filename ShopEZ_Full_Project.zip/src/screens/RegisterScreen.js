import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, Alert } from 'react-native';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../../firebase';

export default function RegisterScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const onRegister = async () => {
    if (!email || !email.includes('@')) return Alert.alert('Invalid email');
    if (!password || password.length < 6) return Alert.alert('Password must be 6+ chars');
    try {
      setLoading(true);
      await createUserWithEmailAndPassword(auth, email.trim(), password);
      Alert.alert('Success', 'Account created!');
      navigation.navigate('Login');
    } catch (e) {
      Alert.alert('Register failed', e.message);
    } finally { setLoading(false); }
  };

  return (
    <View style={{ flex:1, padding:16, gap:12, justifyContent:'center' }}>
      <Text style={{ fontSize:24, fontWeight:'700', marginBottom:8 }}>Create your account</Text>
      <TextInput placeholder="Email" keyboardType="email-address" autoCapitalize='none' value={email} onChangeText={setEmail} style={styles.input} />
      <TextInput placeholder="Password" secureTextEntry value={password} onChangeText={setPassword} style={styles.input} />
      <Pressable onPress={onRegister} style={({pressed})=>[styles.btn,{opacity:pressed||loading?0.7:1}]}>
        <Text style={styles.btnText}>{loading? 'Creating...' : 'Register'}</Text>
      </Pressable>
      <Pressable onPress={()=>navigation.goBack()}>
        <Text>Already have an account? <Text style={{fontWeight:'700'}}>Login</Text></Text>
      </Pressable>
    </View>
  );
}

const styles = {
  input: { borderWidth:1, borderColor:'#e5e7eb', borderRadius:12, padding:12 },
  btn: { backgroundColor:'#111827', padding:14, borderRadius:12, alignItems:'center' },
  btnText: { color:'#fff', fontWeight:'700' }
};
