import React, { useEffect, useLayoutEffect, useState } from 'react';
import { View, FlatList, ActivityIndicator, Alert, Pressable, Text } from 'react-native';
import { fetchCategories, fetchProducts } from '../services/api';
import ProductCard from '../components/ProductCard';
import CategoryFilter from '../components/CategoryFilter';
import { signOut } from 'firebase/auth';
import { auth } from '../../firebase';

export default function ProductListScreen({ navigation }) {
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState(['all']);
  const [selected, setSelected] = useState('all');

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <View style={{ flexDirection:'row', gap:12 }}>
          <Pressable onPress={() => navigation.navigate('Cart')}>
            <Text style={{ fontWeight:'700' }}>Cart</Text>
          </Pressable>
          <Pressable onPress={async ()=>{ try{ await signOut(auth);}catch(e){ Alert.alert('Error', e.message);} }}>
            <Text>Logout</Text>
          </Pressable>
        </View>
      )
    });
  }, [navigation]);

  const load = async (cat='all') => {
    try {
      setLoading(true);
      const [cats, prods] = await Promise.all([
        categories.length > 1 ? Promise.resolve(categories) : fetchCategories(),
        fetchProducts(cat)
      ]);
      setCategories(cats);
      setProducts(prods);
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(selected); }, [selected]);

  if (loading) return <View style={{flex:1,justifyContent:'center',alignItems:'center'}}><ActivityIndicator size='large' /></View>;

  return (
    <View style={{ flex:1 }}>
      <CategoryFilter categories={categories} selected={selected} onSelect={setSelected} />
      <FlatList
        data={products}
        keyExtractor={(item)=>String(item.id)}
        renderItem={({item}) => (
          <ProductCard item={item} onPress={()=>navigation.navigate('ProductDetail', { product: item })} />
        )}
        contentContainerStyle={{ paddingVertical:8 }}
      />
    </View>
  );
}
