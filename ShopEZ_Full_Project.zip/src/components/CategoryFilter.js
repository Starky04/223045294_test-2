import React from 'react';
import { View, ScrollView, Pressable, Text } from 'react-native';

export default function CategoryFilter({ categories, selected, onSelect }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ paddingVertical:8 }}>
      <View style={{ flexDirection:'row', gap:8, paddingHorizontal:12 }}>
        {categories.map(c => (
          <Pressable key={c} onPress={() => onSelect(c)} style={({pressed})=>({
            paddingHorizontal:14, paddingVertical:8, borderRadius:20,
            backgroundColor: selected === c ? '#111827' : '#e5e7eb', opacity: pressed ? 0.8 : 1
          })}>
            <Text style={{ color: selected === c ? '#fff' : '#111827', textTransform:'capitalize' }}>{c}</Text>
          </Pressable>
        ))}
      </View>
    </ScrollView>
  );
}
