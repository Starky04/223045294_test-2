import React from 'react';
import { View, Text, Image, Pressable } from 'react-native';

export default function ProductCard({ item, onPress }) {
  return (
    <Pressable onPress={onPress} style={({pressed})=>({
      flexDirection:'row', gap:12, padding:12, borderRadius:12, backgroundColor:'#fff',
      marginHorizontal:12, marginVertical:6, opacity: pressed ? 0.7 : 1, elevation:2
    })}>
      <Image source={{ uri: item.image }} style={{ width: 70, height: 70, resizeMode:'contain' }} />
      <View style={{ flex:1 }}>
        <Text numberOfLines={2} style={{ fontWeight:'600', marginBottom:6 }}>{item.title}</Text>
        <Text style={{ fontWeight:'700' }}>R {item.price.toFixed(2)}</Text>
      </View>
    </Pressable>
  );
}
