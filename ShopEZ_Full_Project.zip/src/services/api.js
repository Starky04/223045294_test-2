const BASE = 'https://fakestoreapi.com';

export async function fetchProducts(category) {
  const url = category && category !== 'all' ? `${BASE}/products/category/${encodeURIComponent(category)}` : `${BASE}/products`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch products');
  return res.json();
}

export async function fetchCategories() {
  const res = await fetch(`${BASE}/products/categories`);
  if (!res.ok) throw new Error('Failed to fetch categories');
  const cats = await res.json();
  return ['all', ...cats];
}
